/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package CapaArchivo;

import CapaArchivo.ClassColeccionCiudad;
import java.io.BufferedReader;
import java.io.FileReader;

/**
 *
 * @author Alumno
 */
public class ClassArchivoCiudad {
     String ruta="C:\\Users\\renvs\\Downloads\\AppProyectoVentaDeCarros.Final\\AppProyectoVentaDeCarros";
    ClassColeccionCiudad cCiudad=new ClassColeccionCiudad();
    
      
 public void LeerArchivoCiudad(){
        String nomdisco=ruta+"Arch_Ciu.txt";
       FileReader fr;

            try {
            fr = new FileReader(nomdisco);
            BufferedReader br = new BufferedReader(fr);
            String linea = "";
            while ((linea = br.readLine()) != null) {
                // Proceso de lectura y asignacion a la Lista
                String[] campos = linea.split(",");
                ClassEntidadCiudad eCiudad = new ClassEntidadCiudad();
                eCiudad.setCodigo(campos[0]);
                eCiudad.setCiudad(campos[1]);              
                cCiudad.agregarDatosCiudad(eCiudad);
            }
            br.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
 }    
}
