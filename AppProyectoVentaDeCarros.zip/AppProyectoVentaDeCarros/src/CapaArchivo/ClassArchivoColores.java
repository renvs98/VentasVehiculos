/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package CapaArchivo;

import java.io.BufferedReader;
import java.io.FileReader;

/**
 *
 * @author Misael
 */
public class ClassArchivoColores {
     String ruta="C:\\Users\\renvs\\Downloads\\AppProyectoVentaDeCarros.Final\\AppProyectoVentaDeCarros";
    ClassColeccionColores cColores=new ClassColeccionColores();
    
 public void LeerArchivoV(){
        String nomdisco=ruta+"Arch_Colores.txt";
       FileReader fr;

            try {
                fr=new FileReader(nomdisco);
                BufferedReader br=new BufferedReader(fr);
                String linea="";
                while (true) {
                    linea=br.readLine();
                    //System.out.println(linea);
                    if (linea==null) {
                        break;
                    } else {
                        //Proceso de lectura y asignacion a la Lista
                        String[] campos=linea.split(",");
                        ClassEntidadColores eColores=new ClassEntidadColores();
                       eColores.setSwitchColores(campos[0]);
                        eColores.setCodigo(campos[1]);
                        eColores.setColores(campos[2]);
                        cColores.agregarDatosColores(eColores);
                    }
                }                
                br.close();                
            } catch (Exception e) {
            }
 }
}
