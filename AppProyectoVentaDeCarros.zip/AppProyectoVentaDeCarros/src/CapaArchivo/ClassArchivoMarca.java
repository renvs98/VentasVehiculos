/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package CapaArchivo;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

/**
 *
 * @author Misael
 */
public class ClassArchivoMarca {
    String ruta="C:\\Users\\renvs\\Downloads\\AppProyectoVentaDeCarros.Final\\AppProyectoVentaDeCarros";
    ClassColeccionMarca cMarca=new ClassColeccionMarca();
    
    public void LeerArchivoMarca(){
        String nomdisco=ruta+"Arch_cboMarca.txt";
        FileReader fr;

        try {
            fr = new FileReader(nomdisco);
            BufferedReader br = new BufferedReader(fr);
            String linea = "";
            while ((linea = br.readLine()) != null) {
                String[] campos = linea.split(",");
                ClassEntidadMarca eMarca = new ClassEntidadMarca();
                eMarca.setCodigo(campos[0]);
                eMarca.setMarca(campos[1]);
                cMarca.agregarDatosMarca(eMarca);
            }
            br.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }    
   
 public void GrabarModelo(ClassEntidadMarca eMarca,ClassColeccionMarca cMarca){
          FileWriter fw;
        String nomdisco = ruta + "Arch_cboMarca.txt";
        try {
            fw = new FileWriter(nomdisco);
            PrintWriter pw = new PrintWriter(fw);
            System.out.println("grabado");
            for (int i = 0; i < cMarca.TotalRegMarca(); ++i) {
                eMarca = cMarca.obtenerRegMarca(i);
                pw.println(eMarca.getCodigo()+","+eMarca.getMarca());
            }
            pw.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
