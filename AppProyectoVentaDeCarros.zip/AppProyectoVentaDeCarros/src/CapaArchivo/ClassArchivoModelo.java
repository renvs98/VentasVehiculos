/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package CapaArchivo;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

/**
 *
 * @author Misael
 */
public class ClassArchivoModelo {
    String ruta = "C:\\Users\\renvs\\Downloads\\AppProyectoVentaDeCarros.Final\\AppProyectoVentaDeCarros";
    ClassColeccionModelo cModelo = new ClassColeccionModelo();

    public void LeerArchivoModelo() {
        String nomdisco = ruta + "Arch_cboModelo.txt";
        try (FileReader fr = new FileReader(nomdisco);
             BufferedReader br = new BufferedReader(fr)) {

            String linea;
            while ((linea = br.readLine()) != null) {
                // Proceso de lectura y asignacion a la Lista
                String[] campos = linea.split(",");
                ClassEntidadModelo eModelo = new ClassEntidadModelo();
                eModelo.setModNum(campos[0]);
                eModelo.setModCaracter(campos[1]);
                eModelo.setSmarca(campos[2]);
                cModelo.agregarDatosModelo(eModelo);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void GrabarModelo(ClassEntidadModelo eModelo, ClassColeccionModelo cModelo) {
        String nomdisco = ruta + "Arch_cboModelo.txt";
        try (FileWriter fw = new FileWriter(nomdisco);
             PrintWriter pw = new PrintWriter(fw)) {

            System.out.println("grabado");
            for (int i = 0; i < cModelo.TotalRegModelo(); ++i) {
                eModelo = cModelo.obtenerModelo(i);
                pw.println(eModelo.getModNum() + "," + eModelo.getModCaracter() + "," + eModelo.getSmarca());
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
