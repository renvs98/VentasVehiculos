/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package CapaArchivo;

import CapaNEGOCIOS.ClassColecC;
import CapaNEGOCIOS.ClassEntidadC;
import java.util.ArrayList;

/**
 *
 * @author Alumno
 */
public class ClassColeccionCiudad {
    public static ArrayList A_Ciudad = new ArrayList();
    
    public void agregarDatosCiudad(ClassEntidadCiudad ECiudad){
        A_Ciudad.add(ECiudad);
}
    public int TotalRegCiudad(){
    return A_Ciudad.size();
}
    public void QuitarRegCiudad(int fila){
        A_Ciudad.remove(fila);
    }
    public ClassEntidadCiudad obtenerRegCiudad(int fila){
    return (ClassEntidadCiudad)A_Ciudad.get(fila);
  }    
}
