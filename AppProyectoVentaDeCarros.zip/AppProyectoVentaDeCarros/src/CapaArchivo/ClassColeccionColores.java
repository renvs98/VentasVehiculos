/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package CapaArchivo;

import java.util.ArrayList;

/**
 *
 * @author Misael
 */
public class ClassColeccionColores {
    public static ArrayList Colores = new ArrayList();
    
    public void agregarDatosColores(ClassEntidadColores EColores){
        Colores.add(EColores);
}
    public int ToColores(){
    return Colores.size();
}
    public void QuitarRegVehiculo(int fila){
        Colores.remove(fila);
    }
    public ClassEntidadColores obtenerRegColores(int fila){
    return (ClassEntidadColores)Colores.get(fila); 
    }
}
