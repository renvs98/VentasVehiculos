/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package CapaArchivo;

import java.util.ArrayList;

/**
 *
 * @author Misael
 */
public class ClassColeccionMarca {
    public static ArrayList A_Marca = new ArrayList();
    
    public void agregarDatosMarca(ClassEntidadMarca eMarca){
        A_Marca.add(eMarca);
}
    public int TotalRegMarca(){
    return A_Marca.size();
}
    public void QuitarRegMarca(int fila){
        A_Marca.remove(fila);
    }
    public ClassEntidadMarca obtenerRegMarca(int fila){
    return (ClassEntidadMarca)A_Marca.get(fila); 
 }
}
