/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package CapaArchivo;

import java.util.ArrayList;

/**
 *
 * @author Misael
 */
public class ClassColeccionModelo {
    public static ArrayList A_Modelo = new ArrayList();
    
    public void agregarDatosModelo(ClassEntidadModelo eModelo){
        A_Modelo.add(eModelo);
}
    public int TotalRegModelo(){
    return A_Modelo.size();
}
    public void QuitarRegModelo(int fila){
        A_Modelo.remove(fila);
    }
    public ClassEntidadModelo obtenerModelo(int fila){
    return (ClassEntidadModelo)A_Modelo.get(fila); 
 }
}
