/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package CapaArchivo;

/**
 *
 * @author Misael
 */
public class ClassEntidadColores {
     String Codigo,Colores,SwitchColores;

    public String getSwitchColores() {
        return SwitchColores;
    }

    public void setSwitchColores(String SwitchColores) {
        this.SwitchColores = SwitchColores;
    }

    public String getCodigo() {
        return Codigo;
    }

    public void setCodigo(String Codigo) {
        this.Codigo = Codigo;
    }

    public String getColores() {
        return Colores;
    }

    public void setColores(String Colores) {
        this.Colores = Colores;
    }
}
