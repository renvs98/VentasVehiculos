/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package CapaArchivo;

/**
 *
 * @author Misael
 */
public class ClassEntidadModelo {
     String ModNum, ModCaracter, Smarca;

    public String getModNum() {
        return ModNum;
    }

    public void setModNum(String ModNum) {
        this.ModNum = ModNum;
    }

    public String getModCaracter() {
        return ModCaracter;
    }

    public void setModCaracter(String ModCaracter) {
        this.ModCaracter = ModCaracter;
    }

    public String getSmarca() {
        return Smarca;
    }

    public void setSmarca(String Smarca) {
        this.Smarca = Smarca;
    }
}
