/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package CapaDATOS;

import CapaNEGOCIOS.ClassColecC;
import CapaNEGOCIOS.ClassEntidadC;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

/**
 *
 * @author Misael
 */
public class ClassArchivoC {
     String ruta="C:\\Users\\renvs\\Downloads\\AppProyectoVentaDeCarros.Final\\AppProyectoVentaDeCarros";
    ClassColecC cCliente=new ClassColecC();
    
 public void LeerArchivoCliente(){
        String nomdisco=ruta+"Arch_C.txt";
       FileReader fr;

            try {
            fr = new FileReader(nomdisco);
            BufferedReader br = new BufferedReader(fr);
            String linea = "";
            while ((linea = br.readLine()) != null) {
                // Proceso de lectura y asignacion a la Lista
                String[] campos = linea.split(",");
                ClassEntidadC eCliente = new ClassEntidadC();
                eCliente.setApeynom(campos[0]);
                eCliente.setFecha(campos[1]);
                eCliente.setEdad(Integer.parseInt(campos[2]));
                eCliente.setCorreo(campos[3]);
                eCliente.setTelefono(campos[4]);
                eCliente.setCiudad(campos[5]);
                eCliente.setGenero(campos[6]);
                eCliente.setTipodepago(campos[7]);
                cCliente.agregarDatosCliente(eCliente);
            }
            br.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
 }    
   
 public void GrabarCliente(ClassEntidadC eCliente,ClassColecC cCliente){
          FileWriter fw;
          String nomdisco = ruta + "Arch_C.txt";
        try {
            fw = new FileWriter(nomdisco);
            PrintWriter pw = new PrintWriter(fw);
            System.out.println("grabado");
            for (int i = 0; i < cCliente.TotalRegCliente(); ++i) {
                eCliente = cCliente.obtenerRegC(i);
                pw.println(eCliente.getApeynom() + "," + eCliente.getFecha() + "," + eCliente.getEdad() + ","
                        + eCliente.getCorreo() + "," + eCliente.getTelefono() + "," + eCliente.getCiudad() + ","
                        + eCliente.getGenero() + "," + eCliente.getTipodepago());
            }
            pw.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
            //        "Codigo","Apellidos y Nombres","Edad","Correo","Telefono",
//        "Ciudad","Genero","Metodo de Pago"
 }
}