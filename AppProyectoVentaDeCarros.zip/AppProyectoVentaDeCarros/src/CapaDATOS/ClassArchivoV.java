/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package CapaDATOS;

import CapaNEGOCIOS.ClassColecV;
import CapaNEGOCIOS.ClassEntidadV;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

/**
 *
 * @author Sebastian
 */
public class ClassArchivoV {
    String ruta="C:\\Users\\renvs\\Downloads\\AppProyectoVentaDeCarros.Final\\AppProyectoVentaDeCarros";
    ClassColecV cVehiculo=new ClassColecV();
    
 public void LeerArchivoV(){
        String nomdisco=ruta+"Arch_V.txt";
       FileReader fr;

            try {
                fr=new FileReader(nomdisco);
                BufferedReader br=new BufferedReader(fr);
                String linea="";
                while (true) {
                    linea=br.readLine();
                    //System.out.println(linea);
                    if (linea==null) {
                        break;
                    } else {
                        //Proceso de lectura y asignacion a la Lista
                        String[] campos=linea.split(",");
                        ClassEntidadV eVehiculo=new ClassEntidadV();
                        eVehiculo.setMarca(campos[0]);
                        eVehiculo.setModelo(campos[1]);
                        eVehiculo.setNumeroSerie(campos[2]);
                        eVehiculo.setFechaCom(campos[3]);
                        eVehiculo.setColor(campos[4]);
                        eVehiculo.setEstado(campos[5]);
                        eVehiculo.setPrecioCompra(Integer.parseInt(campos[6]));
                        cVehiculo.agregarDatosVehiculo(eVehiculo);
                    }
                }                
                br.close();                
            } catch (Exception e) {
            }
        }    
   
 public void GrabarVehiculo(ClassEntidadV eVehiculo,ClassColecV cVehiculo){
          FileWriter fw;
          String nomdisco=ruta+"Arch_V.txt";
            try {
            fw = new FileWriter(nomdisco);            
            PrintWriter pw=new PrintWriter(fw);
            //System.out.print("grabado");
           for (int i = 0; i < cVehiculo.TotalRegVehiculo(); ++i) {
            eVehiculo = cVehiculo.obtenerRegV(i);
            pw.println(eVehiculo.getMarca() + "," + eVehiculo.getModelo() + "," + eVehiculo.getNumeroSerie()
                    + "," + eVehiculo.getFechaCom() + "," + eVehiculo.getColor() + "," + eVehiculo.getEstado()
                    + "," + eVehiculo.getPrecioCompra());
            }
                pw.close();
            } catch (IOException e) {
           e.printStackTrace();
        }
}
}
