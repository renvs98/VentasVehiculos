/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package CapaNEGOCIOS;

import java.util.ArrayList;

/**
 *
 * @author Misael
 */
public class ClassColecC {
public static ArrayList A_Cliente = new ArrayList();
    
    public void agregarDatosCliente(ClassEntidadC ECliente){
        A_Cliente.add(ECliente);
}
    public int TotalRegCliente(){
    return A_Cliente.size();
}
    public void QuitarRegCliente(int fila){
        A_Cliente.remove(fila);
    }
    public ClassEntidadC obtenerRegC(int fila){
    return (ClassEntidadC)A_Cliente.get(fila);
  }    
 }
