/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package CapaNEGOCIOS;

import java.util.ArrayList;

/**
 *
 * @author Misael
 */
public class ClassColecV {
public static ArrayList A_Vehiculo = new ArrayList();
    
    public void agregarDatosVehiculo(ClassEntidadV EVehiculo){
        A_Vehiculo.add(EVehiculo);
}
    public int TotalRegVehiculo(){
    return A_Vehiculo.size();
}
    public void QuitarRegVehiculo(int fila){
        A_Vehiculo.remove(fila);
    }
    public ClassEntidadV obtenerRegV(int fila){
    return (ClassEntidadV)A_Vehiculo.get(fila); 
 }
    }

