/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package CapaNEGOCIOS;

import javax.swing.JComboBox;

/**
 *
 * @author Sebastian
 */
//ESTE ES EL METODOS DEL CLIENTE
public class ClassMetodosC implements intMetodosC{

    @Override
    public int edad(int ac, int an) {
                return ac - an;
    }

    @Override
    public void llenarCiudad(JComboBox cboCiudad) {
        String ciudades[]={"Lima","Cuzco","Arequipa","Trujillo","Chiclayo","Iquitos"," Piura","Chimbote","Puno","Huancayo"};
        for (String ciudad:ciudades){
        cboCiudad.addItem(ciudad);
    }
   }
  }
