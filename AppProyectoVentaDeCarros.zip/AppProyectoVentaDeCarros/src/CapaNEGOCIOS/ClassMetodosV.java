/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package CapaNEGOCIOS;

import java.awt.Image;
import javax.swing.ImageIcon;
import javax.swing.JComboBox;
import javax.swing.JLabel;

/**
 *
 * @author Sebastian
 */
//ESTE ES EL METODOS DEL VEHICULO
public class ClassMetodosV implements intMetodosV {

    @Override
    public double HallarPrecio(int OrdenV,int OrdenM) {         
        if(OrdenM== 0){
            switch(OrdenV){
                case 0: return 279055.0;
                case 1: return 214448.0;
                case 2: return 214048.0;
            }
        }
        if(OrdenM== 1){
            switch(OrdenV){
                case 0: return 15400.0;
                case 1: return 21715.0;
                case 2: return 86900.0;
            }
        }
        if(OrdenM== 2){
            switch(OrdenV){
                case 0: return 40700.0;
                case 1: return 231675.0;
                case 2: return 103600.0;
            }
        }
       if(OrdenM== 3){
           switch(OrdenV){
               case 0: return 74475.0;
               case 1: return 59585.0;
               case 2: return 260789.0;
           }
       }
       if(OrdenM== 4){
           switch(OrdenV){
               case 0: return 108619.0;
               case 1: return 95996.0;
               case 2: return 69700;
           }
       }
        return 0;
                    
    }

    @Override
    public void LLenarColor(JComboBox cboColor, int OrdenMarca) {
        switch (OrdenMarca) {
        case 0: // Marca 0
            cboColor.addItem("Rojo");
            cboColor.addItem("Rojo Claro");
            cboColor.addItem("Rojo Oscuro");
            break;
        case 1: // Marca 1
            cboColor.addItem("Cafe");
            cboColor.addItem("Rojo Claro");
            cboColor.addItem("Platido");
            break;
        case 2: // Marca 2
            cboColor.addItem("Negro");
            cboColor.addItem("Verde Agua");
            cboColor.addItem("Platido");
            break;
        case 3: // Marca 3
            cboColor.addItem("Marron");
            cboColor.addItem("Azul");
            cboColor.addItem("Azulino");
            break;
        case 4: // Marca 4
            cboColor.addItem("Blanco");
            cboColor.addItem("Verde Esmeralda");
            cboColor.addItem("Azul Marino");
            break;
        default:
            break;
    }
    }

    @Override
    public void LLenarMarca(JComboBox cboMarca) {
        
                String Modelos[]={"Ferrari","Ford","BMW","Mercedes","Porsche"};
        for (String mode:Modelos){
        cboMarca.addItem(mode);
        }
    }

    @Override
    public void LLenarModelo(JComboBox cboModelo, int OrdenMarca) {
                if(OrdenMarca==0){
            cboModelo.addItem("296 GTB");
            cboModelo.addItem("458");
            cboModelo.addItem("California T");
        }
        if(OrdenMarca==1){
            cboModelo.addItem("B-Max");
            cboModelo.addItem("Bronco");
            cboModelo.addItem("C-Max");
        }
        if(OrdenMarca==2){
            cboModelo.addItem("i3");
            cboModelo.addItem("XM");
            cboModelo.addItem("Serie 8");
        }
        if(OrdenMarca==3){
            cboModelo.addItem("Maybach Clase S");
            cboModelo.addItem("Marco Polo");
            cboModelo.addItem("CLS");
        }
        if(OrdenMarca==4){
            cboModelo.addItem("Macan");
            cboModelo.addItem("Taycan Cross Turismo");
            cboModelo.addItem("Cayenne");   
        }


    }

    @Override
    public void aclopar(String Ximagen, JLabel lblImagen) {
        ImageIcon imagen = new ImageIcon(Ximagen);
        Image image = imagen.getImage().getScaledInstance(lblImagen.getWidth(), lblImagen.getHeight(), Image.SCALE_SMOOTH);
        ImageIcon imagenAjustada = new ImageIcon(image);
        lblImagen.setIcon(imagenAjustada);
    }
}
