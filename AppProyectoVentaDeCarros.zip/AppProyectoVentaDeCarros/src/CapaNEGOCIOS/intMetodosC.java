/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package CapaNEGOCIOS;

import javax.swing.JComboBox;

/**
 *
 * @author Sebastian
 */
//ESTE ES EL METODOS DEL CLIENTE
// AQUI RELLENAN EL COMBOBOX
public interface intMetodosC {
    int edad(int ac, int an);
    void llenarCiudad (JComboBox cboCiudad);
}
