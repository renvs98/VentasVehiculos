/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package CapaNEGOCIOS;

import javax.swing.JComboBox;
import javax.swing.JLabel;

/**
 *
 * @author Sebastian
 */
//ESTE ES EL METODOS PARA EL VEHICULO
//AQUI RELLENAN LOS COMBOBOX
public interface intMetodosV {
     double HallarPrecio(int OrdenV, int OrdenM);
    void LLenarColor(JComboBox cboColor, int OrdenMarca);
    void LLenarMarca(JComboBox cboMarca);
    void LLenarModelo(JComboBox cboModelo, int OrdenMarca);
    void aclopar(String Ximagen, JLabel lblImagen);
}
